# No WhiteOut

***Now also works in TNH*** 
Removes the high altitude whiteout effect in Winter Wasteland. Now you can snipe those mines from the TIPPITY TOP!

