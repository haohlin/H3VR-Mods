# The Ping

REALISTIC VOLUME CURVE! Receive sound feedback out to 2500m. Now go ring some steel across the map!

## Recommend
[Teleport](https://h3vr.thunderstore.io/package/HLin_Mods/Teleport/), which saves you from spamming the teleport key when setting up targets.

[FTW Spawnable Targets](https://h3vr.thunderstore.io/package/Andrew_FTW/FTW_Arms_Spawnable_Targets/), which adds a huge selection of steel targets.
